import os
import shutil


# Вывести кол-во файлов
# array = [10, 20, 30]
# print(len(array))  # -> 3
def print_count():
    pass


# Удалить пустые файлы (весит 0 байт)
# os.path.getsize('path-to-file')  # -> file size
# os.remove('path-to-file')
def remove_empty():
    pass


# Вывести на экран файлы, содержащие паттерн
# 'we' in 'qwerty'  # -> True
# 'ew' in 'qwerty'  # -> False
def find_by_pattern(pattern: str):
    pass


# Любая идея в рамках папки Downloads
def custom_function():
    pass


# Возвращает всё как было
def restore():
    core_dir = os.getcwd()
    os.chdir('Downloads_backup')
    files = next(os.walk(os.getcwd()))[2]
    os.chdir(core_dir)
    for file in files:
        shutil.copy(os.path.join('Downloads_backup', file), os.path.join('Downloads', file))


if __name__ == '__main__':
    restore()
